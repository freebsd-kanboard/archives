<?php

namespace Kanboard\Event;

class TaskLinkEvent extends GenericEvent
{
}
