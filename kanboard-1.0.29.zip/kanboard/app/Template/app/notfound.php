<section id="main">
    <p class="alert alert-error">
        <?= t('Sorry, I didn\'t find this information in my database!') ?>
    </p>
</section>