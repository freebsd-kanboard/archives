<?php

namespace Kanboard\Event;

class FileEvent extends GenericEvent
{
}
