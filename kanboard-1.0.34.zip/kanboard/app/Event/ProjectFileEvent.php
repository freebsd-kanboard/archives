<?php

namespace Kanboard\Event;

class ProjectFileEvent extends GenericEvent
{
}
